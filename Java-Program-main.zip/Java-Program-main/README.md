work of java
